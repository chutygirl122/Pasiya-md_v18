export default [{
  name: "say",
  code: ({ query }) => {
    return "You say: " + query;
  }
}]